INSERT INTO employes VALUES
(1, 'DUFONT', 'Marie', 'marie.dufont@example.com', '192.168.2.2', '2024-01-01 10:00:00', '2024-01-01 10:00:00'),
(2, 'DESBOIS', 'Paul', 'paul.desbois@example.com', '192.168.2.1', '2024-01-01 10:05:00', '2024-01-01 10:05:00'),
(3, 'DURANTON', 'Quentin', 'quentin.duranton@example.com', '192.168.2.3', '2024-01-01 10:10:00', '2024-01-01 10:10:00'),
(4, 'LEJAUNE', 'Laurence', 'laurence.lejaune@example.com', '192.168.2.100', '2024-01-01 10:15:00', '2024-01-01 10:15:00');

INSERT INTO journaux_acces VALUES
(1, '192.168.2.2', '2024-01-02 10:00:00', 'http://example.com/page1', 'GET', '200', '2024-01-02 10:00:00', '2024-01-02 10:00:00'),
(2, '192.168.2.1', '2024-01-02 10:05:00', 'http://example.com/page2', 'POST', '201', '2024-01-02 10:05:00', '2024-01-02 10:05:00');
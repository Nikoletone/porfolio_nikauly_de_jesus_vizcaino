CREATE TABLE `employes` (
  `id_employe` int(11) NOT NULL COMMENT 'Identifiant unique de l''employé',
  `nom` varchar(50) NOT NULL COMMENT 'nom de famille',
  `prenom` varchar(50) NOT NULL COMMENT 'prénom',
  `email` varchar(100) NOT NULL COMMENT 'adresse e-mail',
  `adresse_ip` varchar(15) NOT NULL COMMENT 'adresse ip de l''employé',
  `date_creation` datetime NOT NULL COMMENT 'date et heure de création de l''enregistrement',
  `date_modif` datetime NOT NULL COMMENT 'Date et heure de la dernière mise à jour',
  PRIMARY KEY (`id_employe`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `adresse_ip` (`adresse_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `journaux_acces` (
  `id_acces` int(11) NOT NULL COMMENT 'identifiant unique de l''accès',
  `adresse_ip_employe` varchar(15) NOT NULL COMMENT 'adresse ip de l''employé',
  `horodotage` datetime NOT NULL COMMENT 'date et heure d''accès',
  `url_consultee` text NOT NULL COMMENT 'url consultée',
  `methode_http` varchar(10) NOT NULL COMMENT 'méthode http utilisée',
  `code_reponse` int(11) NOT NULL COMMENT 'code réponse',
  `date_creation` datetime NOT NULL COMMENT 'date et heure de création de l''enregistrement',
  `date_modification` datetime NOT NULL COMMENT 'date et heure de la dernière mise à jour',
  PRIMARY KEY (`id_acces`),
  UNIQUE KEY `employe_adresse_ip` (`adresse_ip_employe`),
  CONSTRAINT `journaux_acces_ibfk_1` FOREIGN KEY (`adresse_ip_employe`) REFERENCES `employes` (`adresse_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
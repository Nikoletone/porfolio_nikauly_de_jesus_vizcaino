
import os

# REMARQUE : Pour que le script fonctionne sur votre machine, pensez à changer les chemins de chaque dossier
# Le premier est le dossier où se trouvent les fichiers log
dossier = r'C:\Users\G L O R Y X\Desktop\Projet python 2024-2025\logs_txt'
# Chemin du dossier où l'on veut stocker les requêtes SQL
dossier_insert = r'C:\Users\G L O R Y X\Desktop\Projet python 2024-2025\log_sql'

fichiers = os.listdir(dossier)  # Liste les fichiers et dossiers dans le dossier

def menue() -> int:
    """
    Affiche un menu des fichiers disponibles et demande à l'utilisateur de choisir un fichier.

    Returns:
        int: L'index du fichier choisi dans la liste des fichiers (ajusté pour l'indexation à partir de 0).
    """
    for i, fichier in enumerate(fichiers, 1):
        print(f"{i} {fichier}")
    choix = int(input("entre le numero du fichier voulue : "))
    return choix - 1

nom_fichier = fichiers[menue()]  # Isole le nom du dossier voulu
chemin_fichier = os.path.join(os.getcwd(), dossier, nom_fichier)  # Chemin complet du fichier choisi

with open(chemin_fichier, 'r') as f:  # Ouverture du fichier en mode lecture
    contenue = f.readlines()  # On ajoute le contenu dans une liste ligne par ligne

isolation_nom_sorti = nom_fichier[10:20]  # Isole la date du nom du fichier pour créer le fichier SQL

donnes = []  # Liste vide pour stocker les données du fichier log

def separation_en_partie():
    """
    Sépare chaque ligne du fichier log en parties et les ajoute à la liste donnes.
    Modifie également le format de la date pour chaque entrée.
    """
    for i in contenue:
        parties = i.split()
        parties[0] = f"{isolation_nom_sorti}  {parties[0]}"
        donnes.append(parties)

separation_en_partie()  # Appel de la fonction pour effectuer la séparation en parties

def creation_fichier_sql():
    """
    Crée un fichier SQL et y écrit des requêtes INSERT basées sur les données du fichier log.

    Le fichier SQL est nommé selon le format 'insert_log_YYYY-MM-DD.sql' et est créé dans le dossier spécifié.
    Chaque ligne du fichier log est convertie en une requête INSERT INTO.
    """
    nom_fichier_sql = f"insert_log_{isolation_nom_sorti}.sql"
    chemin_fichier_2 = os.path.join(os.getcwd(), dossier_insert, nom_fichier_sql)
    with open(chemin_fichier_2, 'w') as f:
        for i in donnes:
            f.write(f"INSERT INTO acces_log VALUES ({', '.join([f'\"{v}\"' for v in i])});\n")

creation_fichier_sql()  # Appel de la fonction pour créer le fichier SQL et écrire les requêtes1

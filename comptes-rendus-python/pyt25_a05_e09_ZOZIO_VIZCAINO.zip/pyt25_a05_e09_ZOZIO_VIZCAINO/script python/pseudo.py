import random
#on import le module random pour pourvoir generer des nombres aleatoires

#ouverture du fichier
with open(r'C:\Users\G L O R Y X\Desktop\Projet python 2024-2025\pseudo\textEntrer.txt', 'r') as f:
    contenu = f.readlines()#ici on ajoute le fichier le contenu du fichier dans une liste
    
def isolatiion_lettre_prenomm():
    isolation_prenom= nom[0]
    isolation_lettre_prenom = isolation_prenom[0:1].lower() 
    return isolation_lettre_prenom  
 
def isolatiion_lettre_nom():
    isolation_nom = nom[1]
    isolation_lettre_nom = isolation_nom[0:3].lower()
    return isolation_lettre_nom

def calculeAge():
    isolation_annee_naissance = int(nom[2])#ici on tranformer la chaine de caractere en entier et on isole 
    calcule_age = str(2025 - isolation_annee_naissance)#ici on calcule l'age puis on trenforme les entiers en chaines de caracteres
    return calcule_age

def numeroAleatoire():
    numero_random = str(random.randint(10,99))#genre le nombre aletoire et on le tranformer ce nombre en chaine de caractere 
    return numero_random

listes_pseudonyme = []#creation liste vide
for i in contenu:
    nom = i.strip().split(';')#on supprimer les \n et on les separer au niveau du ; 
    pseudonyme = isolatiion_lettre_prenomm() + isolatiion_lettre_nom()+calculeAge()+numeroAleatoire()
    listes_pseudonyme.append(pseudonyme)



for j in listes_pseudonyme : 
    with open(r'C:\Users\G L O R Y X\Desktop\Projet python 2024-2025\pseudo\testSortie1.txt', 'a') as n:
        n.write(j + '\n')#on ajoute les pseudonyme au fichier .txt
    
        

    


    
    
    

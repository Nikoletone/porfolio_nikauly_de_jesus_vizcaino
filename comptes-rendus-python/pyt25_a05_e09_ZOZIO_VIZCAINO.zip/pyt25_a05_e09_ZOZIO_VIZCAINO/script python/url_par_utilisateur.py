

import os#importation du module os qui nous aideras a pourvoir afficher les fichiers d'un dossier ainsi que d'avoir leurs chemin 


dossier = r'C:\Users\G L O R Y X\Desktop\Projet python 2024-2025\logs_txt'#chemin du dosier du quelle on veut afficher le contenue

fichiers = os.listdir(dossier)  # Liste les fichiers et dossiers dans le dossier

n = 0 #compter
# Affiche les fichiers dans le dossier
for fichier in fichiers:
    n += 1#augmente a chaque fichier pour que chaque ai leurs propre numero atribue
    print (f"{n} {fichier}")#ici on affiche les fichiers dans le dossier ainsi que un numero que leurs coresponds
choix  = int(input("entre le numero du fichier voulu : "))

nom_fichier = fichiers[choix - 1] #ici on isole le nom de dossier voulu
chemin_fichier = os.path.join(os.getcwd(),dossier, nom_fichier )#ici on cherche le chemin au quelle apartien le nom du dossier 

with open(chemin_fichier, 'r') as f: #overture du fichier
    contenue = f.readlines()#on stoke chauque ligne du fichier dans une list

urls = []#on creer une liste vide pour stoker que les urls 
for i in contenue:#on utilise la bouble for pour parcourir chauque elements dans la list contenue
    separation = i.split()#on utilise split pour separer chaque elements elements au niveau de l'espace
    for j in separation:#on uliser une deuxieme boucle cette fois pour une parcourir chauque elements dans chaque elements de la list contenue
        if j.startswith("http://") or j.startswith("https://"):#ici on verifier si les elements de la boucle deuxieme boucle commence soit par https:// ou https://
           urls.append(j)#si oui chaque elements sera ajouter directement dans la liste vide (urls)

urls_plus_visiter = ''
nombre_de_visites = 0 


for url in urls:
    nombre_dans_lis = urls.count(url)
    if nombre_dans_lis > nombre_de_visites:
        nombre_de_visites = nombre_dans_lis
        urls_plus_visiter = url

print(urls_plus_visiter)
print(nombre_de_visites)
